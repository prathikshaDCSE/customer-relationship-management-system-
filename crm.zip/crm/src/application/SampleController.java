package com.example.customer_relationship;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;

public class SampleController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void initialize() {

    }

}
